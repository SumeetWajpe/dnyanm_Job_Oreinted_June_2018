import { Component } from '@angular/core';
import {Course} from './course.model';

// decorator -> metadata about the class
@Component({
  selector: 'app-root',
  templateUrl:`./app.component.html`
  , styleUrls:['./course.style.css']  
})
export class AppComponent {
    title:string="Online Tuts";
    newCourse:Course = new Course();
    

    courses:Course[] = [new Course("React",20000,'3 Days',"https://cdn-images-1.medium.com/max/900/1*EntHChgUyirgbZ9A3zTxkA.png",5,100,40,20,new Date()),
     new Course("Node",20000,'5 Days',"https://miro.medium.com/max/1400/1*z2199oLqkusRx_6LcUF0SA.png",3,200,30,50,new Date()),
    new Course("Polymer",10000,'2 Days',"https://cdn-images-1.medium.com/max/728/1*wtCI-KjMRFbhfqpkY4roIg.png",4,600,60,10,new Date()),
    new Course("VueJS",10000,'2 Days',"https://cdn-images-1.medium.com/max/1200/1*OrjCKmou1jT4It5so5gvOA.jpeg",5,500,80,0,new Date()),
    new Course(".NET",10000,'5 Days',"https://avatars0.githubusercontent.com/u/10201666?s=400&v=4",5,60,10,80,new Date()),
    new Course("C#",10000,'6 Days',"https://www.javatpoint.com/csharp/images/c-sharp.png",2,100,5,0,new Date()),
    new Course("VB.NET",10000,'8 Days',"https://1.bp.blogspot.com/-VuhOCRoGzsY/WmBZ7iDUtYI/AAAAAAAAAPA/3Adnaoj-WUEkLqebhle-C4VSBAhZES92ACLcBGAs/s1600/vbnet.png",3.677,100,4,300,new Date())

];

OnFormSubmit(theForm:any){
    
    
    if(theForm.valid){
        this.courses.push(this.newCourse);
        this.newCourse = new Course();  
        theForm.reset();// resetting the form !
    }

}

}


