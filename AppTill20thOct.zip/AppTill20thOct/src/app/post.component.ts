import {Component, Input} from '@angular/core'
import {posts} from './posts';

@Component({
    selector:`post`,
    templateUrl:`./course.template.html`,
    styleUrls:['./course.style.css']
})
export class PostsComponent{

    allPosts:Post[] = posts;

}