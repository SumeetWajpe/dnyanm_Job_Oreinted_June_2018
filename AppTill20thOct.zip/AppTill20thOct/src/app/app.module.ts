import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';


import { AppComponent } from './app.component';
import {CourseComponent} from './course.component';
import { QuantityPipe } from './quantity.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    QuantityPipe
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
