import {Component, Input} from '@angular/core'
import { Course } from './course.model';

@Component({
    selector:`course`,
    templateUrl:`./course.template.html`
})
export class CourseComponent{
    @Input()    coursedetails:Course = {name:"Angular",price:40000,duration:'3 Days',ImageUrl:"https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/300/full/angular2.png"}; // model !   
    IncrementLikes(){
        this.coursedetails.likes+=1;// change the model to update the UI !
    }

    DecrementLikes(){
        this.coursedetails.dislikes-=1;
    }

}