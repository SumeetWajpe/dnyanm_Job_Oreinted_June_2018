export class Course{
    constructor(        public name?:string,
        public price?:number,
        public duration?:string,
        public ImageUrl?:string,
        public rating?:number,
        public likes?:number,
        public dislikes?:number
    ){
    }
}