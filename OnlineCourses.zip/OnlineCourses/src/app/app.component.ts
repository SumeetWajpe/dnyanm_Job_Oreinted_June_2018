import { Component } from '@angular/core';
import {Course} from './course.model';

// decorator -> metadata about the class
@Component({
  selector: 'app-root',
  template:`  
  
  <div class="jumbotron">
        <h1> {{title}}  </h1>       
        <input  type="text" [(ngModel)]="title" />
  </div>
  <div class="row">
  <div   *ngFor="let c of courses">
        <div class="col-xs-5 Highlight CourseStyle" >
            <course [coursedetails]="c" ></course>
        </div>
  </div>     
  </div>  
  `  , styleUrls:['./course.style.css']  
})
export class AppComponent {
    title:string="";
    courses:Course[] = [new Course("React",20000,'3 Days',"https://cdn-images-1.medium.com/max/900/1*EntHChgUyirgbZ9A3zTxkA.png",5,100,40),
     new Course("Node",20000,'5 Days',"https://miro.medium.com/max/1400/1*z2199oLqkusRx_6LcUF0SA.png",3,200,30),
    new Course("Polymer",10000,'2 Days',"https://cdn-images-1.medium.com/max/728/1*wtCI-KjMRFbhfqpkY4roIg.png",4,600,60),
    new Course("VueJS",10000,'2 Days',"https://cdn-images-1.medium.com/max/1200/1*OrjCKmou1jT4It5so5gvOA.jpeg",5,500,80),
    new Course(".NET",10000,'5 Days',"https://avatars0.githubusercontent.com/u/10201666?s=400&v=4",5,60,10),
    new Course("C#",10000,'6 Days',"https://www.javatpoint.com/csharp/images/c-sharp.png",2,100,5),
    new Course("VB.NET",10000,'8 Days',"https://1.bp.blogspot.com/-VuhOCRoGzsY/WmBZ7iDUtYI/AAAAAAAAAPA/3Adnaoj-WUEkLqebhle-C4VSBAhZES92ACLcBGAs/s1600/vbnet.png",3.677,100,4)

];


}


