import { Course } from "./course.model";
import { Injectable } from "@angular/core";
import { CourseService } from "./course.service";

@Injectable()
export class CartService{
    
    currentItems:Course[] = new Array<Course>();
    constructor(public courseServObj:CourseService){}

    AddItemToCart(itemToBeAdded:Course){
            this.currentItems.push(itemToBeAdded);
    }
    RemoveItemFromCart(itemToBeRemoved:Course){
        var itemIndex = this.currentItems.findIndex(
            (c)=> c.name == itemToBeRemoved.name
         );
         this.currentItems.splice(itemIndex,1);// Remove Item
    }

    IncrementItemsCount(){
        this.currentItems.length;
    }
    DecrementItemsCount(){
        this.currentItems.length;       
    }
}