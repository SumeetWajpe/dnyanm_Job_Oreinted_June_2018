import { Component, OnInit } from '@angular/core';
import { Course } from '../course.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-listofcourses',
  templateUrl: './listofcourses.component.html',
  styleUrls: ['./listofcourses.component.css']
})
export class ListofcoursesComponent implements OnInit {

  
   
  
  courses:Course[] = new Array<Course>();

  constructor(public servObj:CourseService) {


       // Using Obeservables !
        // this.servObj.GetAllCourses().subscribe(
        //     (response)=>{
        //             this.servObj.allCourses = response;// assign the service obj with data
        //             this.courses = response;
        //     }
        // )

            // Using Promises !

            if(this.servObj.allCourses.length == 0){
                var aPromise =  this.servObj.GetAllCourses();
                aPromise.then(
                    (response)=>{
                     this.servObj.allCourses = response;
                     this.courses = response;
                    },
                    (err)=>{ console.log(err)})
            }else{
                this.courses = this.servObj.allCourses;
            }

   
   }
  ngOnInit() {
  }

 
}
