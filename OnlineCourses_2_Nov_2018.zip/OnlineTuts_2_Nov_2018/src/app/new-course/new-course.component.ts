import { Component, OnInit } from '@angular/core';
import { Course } from '../course.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-new-course',
  templateUrl: './new-course.component.html',
  styleUrls: ['./new-course.component.css']
})
export class NewCourseComponent implements OnInit {

  newCourse:Course = new Course();
  constructor(public servObj:CourseService) {

   }

  ngOnInit() {
  }
  OnFormSubmit(theForm:any){   
    
    if(theForm.valid){
        this.servObj.AddNewCourse(this.newCourse);// From Service       
        this.newCourse = new Course();  
        theForm.reset();// resetting the form !
    }
}

}
