import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'qty'
})
export class QuantityPipe implements PipeTransform
{
        transform(inputQuantity:number,args:string){
              switch(inputQuantity){
                  case 0:
                  return 'Out of Stock !';                
                  default:
                  return inputQuantity + " " + args;
              }
        }
}