import { Course } from "./course.model";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";

@Injectable()
export class CourseService{
    public allCourses:Course[] = new Array<Course>();
    constructor(public httpObj:HttpClient){     
    }

// GetAllCourses():Observable<Course[]>{
//   return  this.httpObj.get<Course[]>('https://api.myjson.com/bins/ucia2');
// }

GetAllCourses(){
    return  this.httpObj.get<Course[]>('https://api.myjson.com/bins/ucia2').toPromise();
  }

AddNewCourse(courseToBeAdded:Course){
    this.allCourses.push(courseToBeAdded);
}
}