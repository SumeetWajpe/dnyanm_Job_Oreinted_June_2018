import { Component, OnInit } from '@angular/core';
import { Course } from '../course.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-listofcourses',
  templateUrl: './listofcourses.component.html',
  styleUrls: ['./listofcourses.component.css']
})
export class ListofcoursesComponent implements OnInit {

  title:string="Online Tuts";
   
  newCourse:Course = new Course();
  courses:Course[] = new Array<Course>();

  constructor(public servObj:CourseService) {


       // Using Obeservables !
        // this.servObj.GetAllCourses().subscribe(
        //     (response)=>{
        //             this.servObj.allCourses = response;// assign the service obj with data
        //             this.courses = response;
        //     }
        // )

            // Using Promises !

    var aPromise =  this.servObj.GetAllCourses();
    aPromise.then(
        (response)=>{
         this.servObj.allCourses = response;
         this.courses = response;
        },
        (err)=>{ console.log(err)}
        )
   }
  ngOnInit() {
  }

  OnFormSubmit(theForm:any){   
    
    if(theForm.valid){
        this.servObj.AddNewCourse(this.newCourse);// From Service       
        this.newCourse = new Course();  
        theForm.reset();// resetting the form !
    }
}
}
