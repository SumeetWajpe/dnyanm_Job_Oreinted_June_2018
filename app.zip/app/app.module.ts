import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';/* Angular 5 and above ! */

import { AppComponent } from './app.component';
import {CourseComponent} from './course.component';
import { QuantityPipe } from './quantity.pipe';
import { CourseService } from './course.service';
import { CartComponent } from './cart/cart.component';
import { CartService } from './cartService';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    QuantityPipe,
    CartComponent,
    ListofcoursesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,HttpClientModule
  ],
  providers: [CourseService,CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
