import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';/* Angular 5 and above ! */
import {Routes,RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import {CourseComponent} from './course.component';
import { QuantityPipe } from './quantity.pipe';
import { CourseService } from './course.service';
import { CartComponent } from './cart/cart.component';
import { CartService } from './cartService';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';
import { SummaryComponent } from './summary/summary.component';
import { NewCourseComponent } from './new-course/new-course.component';


var routes:Routes = [
  {path:'',component:ListofcoursesComponent},
  {path:'newcourse',component:NewCourseComponent},
  {path:'summary',component:SummaryComponent}
];


@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    QuantityPipe,
    CartComponent,
    ListofcoursesComponent,
    SummaryComponent,
    NewCourseComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [CourseService,CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
