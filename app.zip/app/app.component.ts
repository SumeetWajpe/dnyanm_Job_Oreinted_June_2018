import { Component, Input } from '@angular/core';

// decorator -> metadata about the class
@Component({
  selector: 'app-root',
  templateUrl:`./app.component.html`
  , styleUrls:['./course.style.css']  
})
export class AppComponent {
  title:string="Online Tuts";

    constructor(){ }
    
   



}


