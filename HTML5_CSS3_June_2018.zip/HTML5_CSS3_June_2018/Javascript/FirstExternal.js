        //"use strict";  /* compiler option */
        
        //    var x = 10;
        //    x = "Hello !";
        //    console.log(typeof x);


        var month = "June";  

           function ChangeMonth(){
               //var x = 10;
               month="July"
           }
         
           console.log("Before : " + month);
           ChangeMonth();
           console.log("After : " + month);

