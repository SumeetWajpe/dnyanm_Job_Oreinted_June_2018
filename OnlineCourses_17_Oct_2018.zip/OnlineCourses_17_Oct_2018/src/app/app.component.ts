import { Component } from '@angular/core';
import {Course} from './course.model';

// decorator -> metadata about the class
@Component({
  selector: 'app-root',
  template:`  
  
  <div class="jumbotron">
        <h1> {{title}}  </h1>       
     <!--   <input  type="text" [(ngModel)]="company" /> 

        <ul [ngSwitch]="company">
            <li *ngSwitchCase="'Accenture'" >Accenture ! </li>
            <li *ngSwitchCase="'Microsoft'" >Microsoft ! </li>
            <li *ngSwitchCase="'Sapient'" >Sapient ! </li>
            <li *ngSwitchCase="'IBM'" >IBM ! </li>
            <li *ngSwitchDefault >No Company Found ! </li>
        </ul> -->

        <form  (ngSubmit)="AddCompany()" ngNativeValidate>
        <input required   type="text" [(ngModel)]="company" name="txtCompany" /> 
        <input  type="submit" value="Add " /> 
        </form>
            <ul>
                <li *ngFor="let c of companyNames"> {{c}} </li>
            </ul>
  </div>
  <div class="row">
  <div   *ngFor="let c of courses">
        <div class="col-xs-5">
        <course [coursedetails]="c" ></course>
        </div>
  </div>     
  </div>  
  `  , styleUrls:['./course.style.css']  
})
export class AppComponent {
    title:string="Online Tuts";
    company:string="";
    companyNames:string[]=['IBM','ACCENTURE',"SAPIENT","DELL"];

    courses:Course[] = [new Course("React",20000,'3 Days',"https://cdn-images-1.medium.com/max/900/1*EntHChgUyirgbZ9A3zTxkA.png",5,100,40,20,new Date()),
     new Course("Node",20000,'5 Days',"https://miro.medium.com/max/1400/1*z2199oLqkusRx_6LcUF0SA.png",3,200,30,50,new Date()),
    new Course("Polymer",10000,'2 Days',"https://cdn-images-1.medium.com/max/728/1*wtCI-KjMRFbhfqpkY4roIg.png",4,600,60,10,new Date()),
    new Course("VueJS",10000,'2 Days',"https://cdn-images-1.medium.com/max/1200/1*OrjCKmou1jT4It5so5gvOA.jpeg",5,500,80,0,new Date()),
    new Course(".NET",10000,'5 Days',"https://avatars0.githubusercontent.com/u/10201666?s=400&v=4",5,60,10,80,new Date()),
    new Course("C#",10000,'6 Days',"https://www.javatpoint.com/csharp/images/c-sharp.png",2,100,5,0,new Date()),
    new Course("VB.NET",10000,'8 Days',"https://1.bp.blogspot.com/-VuhOCRoGzsY/WmBZ7iDUtYI/AAAAAAAAAPA/3Adnaoj-WUEkLqebhle-C4VSBAhZES92ACLcBGAs/s1600/vbnet.png",3.677,100,4,300,new Date())

];


AddCompany(){
    this.companyNames.push(this.company);
}

}


